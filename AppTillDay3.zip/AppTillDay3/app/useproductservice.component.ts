
import {Component} from '@angular/core';
import { ProductService } from './product.service';

@Component({
    selector:`prodserv`,
    template:`
    
    <div style="width:400px;border:2px solid red;border-radius:10px;padding:20px;margin:20px">
    <h1> Product Service Consumer </h1>

    <input type="text" [(ngModel)]="theInputProduct" />
    
    <input type="button" value="Add>>"
    (click)="AddProduct()"    
    />

    <input type="button" value="Get Random Product !"
    (click)="GetRandomProduct()"
    
    />

    {{thereceivedProduct}}

    </div>
     `//,
    // providers:[ProductService]
})
export class ProdServComponent{
    thereceivedProduct:string="";
    theInputProduct:string="";
        constructor(public servObj:ProductService){
             
        }

        GetRandomProduct(){
         this.thereceivedProduct =   this.servObj.getRandomProduct()
        }

        AddProduct(){
            this.servObj.insertNewProduct(this.theInputProduct);
        }
}