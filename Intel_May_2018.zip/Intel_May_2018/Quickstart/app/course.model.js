"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Course = (function () {
    function Course(name, duration) {
        this.name = name;
        this.duration = duration;
    }
    return Course;
}());
exports.Course = Course;
//# sourceMappingURL=course.model.js.map