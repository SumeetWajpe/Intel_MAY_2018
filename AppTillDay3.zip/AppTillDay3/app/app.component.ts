import { Component } from '@angular/core';
import {Course} from './course.model';


@Component({
  selector: 'my-app',
  template:`<posts></posts>`
  // template:`<prodserv></prodserv>
  // <prodserv></prodserv>`
  // template:`<shoppingcart></shoppingcart>`
  // template: `

  // <img [src]="imageUrl" height="200px" width="300px" />
  // <img src="{{imageUrl}}" height="200px" width="300px" />
  

  // <div>
  //     <p *ngFor="let c of courses"  [style.backgroundColor]="bgColour" >      
  //           <course [coursedetails]="c"></course>      
  //     </p>
  // </div>
  // `,
})
export class AppComponent  { 

  // bgColour:string="lightblue";
  // imageUrl:string="https://i1.wp.com/opensourceforu.com/wp-content/uploads/2016/06/Angular-JS.jpg?resize=1996%2C1124";

  //   courses:Course[]=[
  //     new Course("React","3 Days"),
  //     new Course("Redux","2 Days"),
  //     new Course("Angular","2 Days"),
  //     new Course("Backbone","3 Days"),
  //     new Course("Node","4 Days")      
  //   ]
}
