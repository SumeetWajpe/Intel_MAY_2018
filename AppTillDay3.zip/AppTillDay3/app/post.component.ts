import {Component,Input} from '@angular/core';
import { PostsService } from './posts.service';


@Component({
        selector:`posts`,
        template:`<h1> Posts </h1>
        `,
        providers:[PostsService]
})
export class PostComponent{

    constructor(public servObj:PostsService){
            this.servObj.getPosts();
    }
    }