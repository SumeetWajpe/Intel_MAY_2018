function MakeAPromise(){

    return new Promise(function(resolve,reject){

        var xmlHttpObj = new XMLHttpRequest();
        xmlHttpObj.open(
            'GET',
            "https://jsonplaceholder.typicde.com/posts"
            );
    xmlHttpObj.send();// Makes the ajax request !
    xmlHttpObj.onreadystatechange = function(){
            // alert(xmlHttpObj.readyState);
            if(xmlHttpObj.readyState == 4 && xmlHttpObj.status == 200){
                   resolve(xmlHttpObj.responseText)
            }  
            else if(xmlHttpObj.readyState == 4 && xmlHttpObj.status != 200){
                    reject(xmlHttpObj.statusText);
            }
        }
    });
}