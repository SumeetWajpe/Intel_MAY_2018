import {Component,Input} from '@angular/core';
import { PostsService } from './posts.service';


@Component({
        selector:`posts`,
        template:`<h1> Posts </h1>
               
        <ul>
                <li *ngFor="let p of allPosts">
                  <a routerLink="/post/{{p.id}}">      {{p.title}}  </a>
                </li>
        </ul>
        `,
        providers:[PostsService]
})
export class PostComponent{
                allPosts:any;
    constructor(public servObj:PostsService){
        //     this.servObj.getPosts(
        //             (dataFromService:any)=>{
        //         this.allPosts = dataFromService;
        //     });

                        let thePromise =  this.servObj.getPosts();
                        thePromise.then(
                                (dataFromService:any)=>{
                                                this.allPosts = dataFromService.json();
                                                localStorage["posts"] = JSON.stringify(this.allPosts)
                                },
                                (err)=>{
                                        console.log(err)
                                }
                        )
    }
    }