import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  showText:boolean= false;

  constructor() { }

  ngOnInit() {
  }

  toggleVisibility(){
    this.showText = true;
  }

}
