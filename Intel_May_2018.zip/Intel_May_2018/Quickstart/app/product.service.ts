export class ProductService{
    products:string[]=[
"Mobile","Laptop","Watches","Shoes"];

getAllProducts():string[]{
    return this.products;
}

insertNewProduct(newProduct:string){
        this.products.push(newProduct);
}

getRandomProduct():string{
    return this.products[Math.floor(Math.random() * this.products.length)];
}


}