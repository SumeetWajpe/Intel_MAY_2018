   
    //    "use strict";

var x = 10;
x = "Hi";


        function ChangeX(){
            x =200;
         console.log(x);            
        }

        ChangeX();
       console.log(x);


       function Addition(x,y){
           return x + y;
       }       

    //    console.log(Addition(10,20));
    //    console.log(Addition("Hello","World!"));      
       
/* Function as expression !*/

var Addition = function(x,y){
    return x +y;
}

// var Addition =  new Function('x','y','return  x + y')

    var cars = ["BMW","FERARRI","AUDI"];

    // for(var i=0;i<cars.length;i++){
    //     console.log(cars[i])
    // }

    // for(var c in cars){
    //     console.log(c);
    // }


/* ES 6 */
    // for(var c of cars){
    //     console.log(c);
    // }

    cars.forEach(function(theCar,index){
        console.log(theCar + "  is at an index " + index)
    });

    var a =10;
    var b = "10";

    // var stringToNumber = parseInt(b);
    var strToNum = +(b);

    if(a === b){
        console.log('a and b are having same value !')
    }

    var result = a ? 'True' : 'False';
    console.log(result);




