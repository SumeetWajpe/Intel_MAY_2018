export class Course{
    constructor(
        public name?:string,
        public duration?:string
    ){

    }
}