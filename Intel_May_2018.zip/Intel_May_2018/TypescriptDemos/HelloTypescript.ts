var x =100; // Type Inference
// x = "Hey !"; // Error !

var str:string; // Type Annotation
var boolVar:boolean;
var y:number;
var z:any;
z = 10;
z = "Hello !";
z = true;
z = ['A','B'];
z={name:'Intel'};

function Addition(x:number,y:number):number | string{

    if(x == 0){
        return 'X cannot be Zero !';
    }
        return x + y;
}
var result:number|string = Addition(20,30);

// function Square():void{
        
// }


// Block scoped Variables

if(true){
    let scopedVar = 1000;
    // let scopedVar = 1000;  // Error !    
    if(true){
      let    scopedVar = 2000;
    }
}
// console.log(scopedVar); // Error !

const PI=3.14;
// PI = 3.1453;

var cars:string[] = ["BMW","AUDI"];
var moreCars:Array<string> = new Array<string>("TATA","HYUNDAI");
var allCars = [...cars,...moreCars]; // Spread operator

for(let car of allCars){
    console.log(car);
}


// Arrow functions (Lambda Expressions)

// function Square(x){
//     return x * x;
// }

// var Square = function(x){
//     return x *x;
// }


// Arrow function


var Square = (x:number) =>   x *x;

allCars.forEach(function(car,index){
        console.log(car);
})

allCars.forEach((car,index)=> console.log(car));

function Emp(){
    this.Salary =20000;
    setTimeout(()=>{
               console.log(this.Salary);
    },0)
}


class Car{
    private id:number;
    public name:string;
    speed:number;

    constructor(theName:string="i20",theSpeed:number=100){
            this.name = theName;
            this.speed = theSpeed;
    }

    Accelerate():string{
        return (this.name + " is running at " + this.speed + " kmph !")
    }
}


// var carObj = new Car();

class JamesBondCar extends Car{
        canfly:boolean;
        useNitroPower:boolean;

        constructor(theName:string,theSpeed:number,fly:boolean,nitro:boolean){
            super(theName,theSpeed);
            this.canfly = fly;
            this.useNitroPower = nitro;
        }       

        Accelerate():string{
                return super.Accelerate() + " Can It Fly ? " + this.canfly;
        }
}

var jbc = new JamesBondCar("Houston",400,true,true);
console.log(jbc.Accelerate());

interface IPerson{
    name:string;
}

interface IEmp extends IPerson{   
    age:number;
    getSalary():void;
}


// var emp:IEmp = {name:'Sumeet',age:32};


class Person{

}

class Employee extends Person implements IEmp{
    name:string;
    age:number;
    getSalary():void{
            console.log('Wait for last working day !')
    }
}


let e = new Employee();






/* Optional Parameters */
// function PrintBook(title:string,author:string,copies?:number){
    
// }

function PrintBook(title:string="Unknown",author:string="Unknown",copies:number=0){
    
}
PrintBook();
PrintBook("India 2020","Dr. APJ Abdul Kalam");

class Book{
  
    constructor(public title:string,public price:number,public author:string){

    }
}


function GetAllBooks():Book[]{
    return [
        new Book("India 2020",400,"Dr. APJ Abdul Kalam"),
        new Book("Wings Of Fire",500,"Dr. APJ Abdul Kalam"),
        new Book("Mrutyunjay",400,"Rannjit Desai"),
        new Book("Radhey",800,"Rannjit Desai")        
    ];
}

let allBooks:Book[] = GetAllBooks();

for(let book of allBooks){
    console.log(`The book  ${book.title} is priced Rs. ${book.price}`)
}

var multiLineStr =`First Line
Second Line
Third Line`



console.log(multiLineStr);