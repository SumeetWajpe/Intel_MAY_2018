
import {Component,Input} from '@angular/core'
import { Product } from './product.model';


@Component({
selector:`product`,
template:`

<div class="ProductStyle">
<h2> {{prodDetails.name | uppercase  }} </h2>

<likes [count]="prodDetails.likes"
  (changesLikes)="ParentEventHandler($event)"></likes>
<br/>
<img [src]="prodDetails.ImageUrl" height="200px" width="200px"  /> <br/>      

Is Free ? : <input type="checkbox" [(ngModel)]="isFree" />
<!-- <p *ngIf="!isFree">
<b> Price :  </b> {{prodDetails.price | currency:'INR':true }} 
</p>-->
<p [style.visibility]="!isFree ? '' : 'hidden' ">
<b> Price :  </b> {{prodDetails.price | currency:'INR':true }} 
</p>
<br/>
                <b> Quantity :  </b> {{prodDetails.quantity | qty:'nos.' }} <br/>                
                <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2' }} <br/> 
                <b> RAW Data : </b> {{prodDetails | json }}
                <b> Likes : </b> {{prodDetails.likes}}
</div>
`,styleUrls:['./app/product.styles.css']

})
export class ProductComponent{
     @Input()   prodDetails=new Product();   
     isFree:boolean=false;

     ParentEventHandler(cnt:number){
         this.prodDetails.likes = cnt;
            console.log(cnt);
     }
    
}