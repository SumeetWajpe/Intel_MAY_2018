var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 100; // Type Inference
// x = "Hey !"; // Error !
var str; // Type Annotation
var boolVar;
var y;
var z;
z = 10;
z = "Hello !";
z = true;
z = ['A', 'B'];
z = { name: 'Intel' };
function Addition(x, y) {
    if (x == 0) {
        return 'X cannot be Zero !';
    }
    return x + y;
}
var result = Addition(20, 30);
// function Square():void{
// }
// Block scoped Variables
if (true) {
    var scopedVar = 1000;
    // let scopedVar = 1000;  // Error !    
    if (true) {
        var scopedVar_1 = 2000;
    }
}
// console.log(scopedVar); // Error !
var PI = 3.14;
// PI = 3.1453;
var cars = ["BMW", "AUDI"];
var moreCars = new Array("TATA", "HYUNDAI");
var allCars = cars.concat(moreCars); // Spread operator
for (var _i = 0, allCars_1 = allCars; _i < allCars_1.length; _i++) {
    var car = allCars_1[_i];
    console.log(car);
}
// Arrow functions (Lambda Expressions)
// function Square(x){
//     return x * x;
// }
// var Square = function(x){
//     return x *x;
// }
// Arrow function
var Square = function (x) { return x * x; };
allCars.forEach(function (car, index) {
    console.log(car);
});
allCars.forEach(function (car, index) { return console.log(car); });
function Emp() {
    var _this = this;
    this.Salary = 20000;
    setTimeout(function () {
        console.log(_this.Salary);
    }, 0);
}
var Car = /** @class */ (function () {
    function Car(theName, theSpeed) {
        if (theName === void 0) { theName = "i20"; }
        if (theSpeed === void 0) { theSpeed = 100; }
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.Accelerate = function () {
        return (this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
// var carObj = new Car();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(theName, theSpeed, fly, nitro) {
        var _this = _super.call(this, theName, theSpeed) || this;
        _this.canfly = fly;
        _this.useNitroPower = nitro;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " Can It Fly ? " + this.canfly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 400, true, true);
console.log(jbc.Accelerate());
// var emp:IEmp = {name:'Sumeet',age:32};
var Person = /** @class */ (function () {
    function Person() {
    }
    return Person;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Employee.prototype.getSalary = function () {
        console.log('Wait for last working day !');
    };
    return Employee;
}(Person));
var e = new Employee();
/* Optional Parameters */
// function PrintBook(title:string,author:string,copies?:number){
// }
function PrintBook(title, author, copies) {
    if (title === void 0) { title = "Unknown"; }
    if (author === void 0) { author = "Unknown"; }
    if (copies === void 0) { copies = 0; }
}
PrintBook();
PrintBook("India 2020", "Dr. APJ Abdul Kalam");
var Book = /** @class */ (function () {
    function Book(title, price, author) {
        this.title = title;
        this.price = price;
        this.author = author;
    }
    return Book;
}());
function GetAllBooks() {
    return [
        new Book("India 2020", 400, "Dr. APJ Abdul Kalam"),
        new Book("Wings Of Fire", 500, "Dr. APJ Abdul Kalam"),
        new Book("Mrutyunjay", 400, "Rannjit Desai"),
        new Book("Radhey", 800, "Rannjit Desai")
    ];
}
var allBooks = GetAllBooks();
for (var _a = 0, allBooks_1 = allBooks; _a < allBooks_1.length; _a++) {
    var book = allBooks_1[_a];
    console.log("The book  " + book.title + " is priced Rs. " + book.price);
}
var multiLineStr = "First Line\nSecond Line\nThird Line";
console.log(multiLineStr);
