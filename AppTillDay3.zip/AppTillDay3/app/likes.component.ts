import {Component,Input,EventEmitter, Output} from '@angular/core';

@Component({
    selector:`likes`,
    template:`
    Likes : {{count}} 

    <input type="button" value="+" (click)="Increment()" />
    <input type="button" value="-" (click)="Decrement()" />
    

    `
})
export class LikesComponent{

 @Output()   changesLikes:EventEmitter<number> = new EventEmitter<number>();

  @Input()   count:number=20;
    Increment(){
            this.count+=1;
            this.changesLikes.emit(this.count); // emit the data !
    }
    Decrement(){
        this.count-=1;
        this.changesLikes.emit(this.count); // emit the data !
        
    }
}