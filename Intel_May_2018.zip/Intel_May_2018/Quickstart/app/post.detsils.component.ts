import {Component,Input,EventEmitter, Output} from '@angular/core';
import { ActivatedRoute } from '@angular/router';


@Component({
    selector:`postdetail`,
    template:`
    <h1> Post Details for {{postId}} </h1>

    `
})
export class PostDetailsComponent{
    postId:number;
        constructor(private currRoute:ActivatedRoute){
            this.currRoute.params.subscribe(
                (p)=>{
                        this.postId = p["id"]
                }
            ); // eof subscribe

            let allPosts = JSON.parse(localStorage["posts"]);

            let thePost = allPosts.find(
                (p:any)=>{
                   return p.id == this.postId
                }
            )
            console.log(thePost);
        }
}