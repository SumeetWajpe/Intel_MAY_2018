
import {Component} from '@angular/core';
import {Product} from './product.model';

@Component({
selector:`shoppingcart`,
templateUrl:`./app/shoppingcart.template.html`,
styles:[
`
input.ng-pristine.ng-invalid{
    background-color:lightblue;
}

input.ng-dirty.ng-valid{
    background-color:lightgreen;
}

input.ng-dirty.ng-invalid{
    border:2px solid red;
}

`

]
})
export default class ShoppingCartComponent{

    heading:string="Shopping Cart";
    isActive:boolean=true;
    newProduct:Product = new Product();
    products:Product[] = [
        new Product('Laptop',40000,30,3,'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70',40),
        new Product('LED TV',50000,20,3,'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg',30),
        new Product('Desktop',20000,40,3,'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg',20),
        new Product('Mobile',30000,50,3,'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg',10),
        new Product('Camera',50000,100,3,'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png',50)
             ];   
             ChangeHeading(){
                 this.heading = "Walmart";
             }

             OnFormSubmit(theForm:any){      
                 
                
                if(theForm.valid){
                    this.products.push(this.newProduct);
                    this.newProduct = new Product();
                    theForm.reset();
                }

            
             }
}


