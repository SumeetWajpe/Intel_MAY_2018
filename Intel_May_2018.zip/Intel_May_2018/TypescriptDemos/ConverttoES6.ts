let numVar:number = 1000;


function Add(x:any,y:any){
    return x + y;
}