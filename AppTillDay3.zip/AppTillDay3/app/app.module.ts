import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'
import { ProductService } from './product.service';


import {CourseComponent} from './course.component';
import { AppComponent }  from './app.component';
import { ProductComponent } from './product.component';
import ShoppingCartComponent from './shoppingcart.component';
import { QuantityPipe } from './quantity.pipe';
import { LikesComponent } from './likes.component';
import { ProdServComponent } from './useproductservice.component';
import {HttpModule} from '@angular/http';
import { PostComponent } from './post.component';

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule ],
  declarations: [ AppComponent,CourseComponent,
    ProductComponent,ShoppingCartComponent,
    PostComponent,
     ProdServComponent
    ,QuantityPipe,LikesComponent ],
  bootstrap:    [ AppComponent ],
  providers:[ProductService]
})
export class AppModule { }
