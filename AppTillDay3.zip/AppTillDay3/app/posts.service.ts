import { Http } from "@angular/http";
import { Injectable } from "@angular/core";

@Injectable()
export class PostsService{
    constructor(public httpservObj:Http){

    }
    getPosts(){
        // make ajaxified request !
        this.httpservObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(responseFromServer){
            console.log( responseFromServer.json());
        })
    }
}